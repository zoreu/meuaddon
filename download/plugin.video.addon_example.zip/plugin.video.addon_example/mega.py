import requests
import re
import json
import base64
import struct

def base64_to_a32(s):
    """Converte base64 para array de 32 bits"""
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * ((4 - len(s) % 4) % 4)
    data = base64.b64decode(s)
    return str_to_a32(data)

def a32_to_str(a):
    """Converte array de 32 bits para string/bytes"""
    return b''.join(x.to_bytes(4, byteorder='big') for x in a)

def str_to_a32(s):
    """Converte string/bytes para array de 32 bits"""
    return [int.from_bytes(s[i:i+4], byteorder='big') for i in range(0, len(s), 4)]

def decrypt_attr(attr, key):
    """Descriptografar atributos do arquivo"""
    from aes import AES
    cipher = AES(a32_to_str(key))
    
    # Tentar descriptografar com AES-ECB (modo simples)
    result = b""
    for i in range(0, len(attr), 16):
        block = attr[i:i+16]
        if len(block) < 16:
            block = block.ljust(16, b'\x00')
        
        block_int = int.from_bytes(block, byteorder='big')
        decrypted_block = cipher.decrypt(block_int)
        result += decrypted_block
    
    # Remover padding PKCS#7
    if result:
        padding_length = result[-1]
        if padding_length <= 16:
            result = result[:-padding_length]
    
    try:
        return json.loads(result.decode('utf-8'))
    except:
        return {"n": "unknown_file"}
    
class CTRCounter:
    """Implementação simples de contador para AES-CTR"""
    def __init__(self, initial_value):
        self.value = initial_value
    
    def increment(self):
        self.value = (self.value + 1) & ((1 << 128) - 1)
        return self.value
    
def mega_to_text(url):
    """Download e descriptografia de arquivo do Mega usando Python puro"""
    
    # Parse do URL
    match = re.search(r"/file/([a-zA-Z0-9_-]+)#([a-zA-Z0-9_-]+)", url)
    if not match:
        raise ValueError("Link inválido")
    
    file_id, file_key_b64 = match.groups()
    
    # Converter chave base64 para array de 32 bits
    file_key = base64_to_a32(file_key_b64)

    # Extrair chave de criptografia e IV (conforme padrão Mega)
    k = [
        file_key[0] ^ file_key[4],
        file_key[1] ^ file_key[5],
        file_key[2] ^ file_key[6],
        file_key[3] ^ file_key[7]
    ]
    
    # Corrigir: converter para lista em vez de tupla
    iv = file_key[4:6] + [0, 0]  # Agora é uma lista
    meta_mac = file_key[6:8]
    
    # Obter informações do arquivo
    api_url = "https://g.api.mega.co.nz/cs?id=1"
    payload = [{"a": "g", "g": 1, "p": file_id}]
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36", "Content-Type": "application/json"}
    
    resp = requests.post(api_url, data=json.dumps(payload), headers=headers)
    file_data = resp.json()[0]
    
    if "g" not in file_data:
        raise Exception("Erro na API MEGA: " + str(file_data))
    
    file_url = file_data['g']
    file_size = file_data['s']
    
    # Descriptografar atributos do arquivo
    if 'at' in file_data:
        try:
            attributes = base64.b64decode(file_data['at'] + '===')
            attributes = decrypt_attr(attributes, k)
            file_name = attributes['n']
        except:
            file_name = f"file_{file_id}.bin"
    else:
        file_name = f"file_{file_id}.bin"
    
    # Download do arquivo
    response = requests.get(file_url)
    response.raise_for_status()
    
    # Configurar AES-CTR manualmente
    from aes import AES
    cipher = AES(a32_to_str(k))
    
    # Calcular valor inicial do contador
    counter_val = ((iv[0] << 32) + iv[1]) << 64
    counter = CTRCounter(counter_val)
    
    encrypted_data = response.content
    decrypted_data = b""
    
    # Processar dados em blocos de 16 bytes
    for i in range(0, len(encrypted_data), 16):
        block = encrypted_data[i:i+16]
        if len(block) < 16:
            block = block.ljust(16, b'\x00')
        
        # Gerar keystream para este bloco
        counter_value = counter.value
        counter.increment()
        
        # Criptografar o contador para gerar keystream
        keystream_block = cipher.encrypt(counter_value)
        
        # XOR com keystream para descriptografar
        decrypted_block = bytes(a ^ b for a, b in zip(block, keystream_block))
        decrypted_data += decrypted_block
    
    # Se o arquivo tem tamanho conhecido, truncar para o tamanho correto
    if file_size and len(decrypted_data) > file_size:
        decrypted_data = decrypted_data[:file_size]
    
    # Tentar decodificar como texto
    try:
        return decrypted_data.decode('utf-8')
    except UnicodeDecodeError:
        return decrypted_data
  

